var searchData=
[
  ['baudrate',['baudrate',['../structp__adcuUartOpt.html#ac4f06ea26ed6bd7ae83b92d64ac10b78',1,'p_adcuUartOpt']]]
];
