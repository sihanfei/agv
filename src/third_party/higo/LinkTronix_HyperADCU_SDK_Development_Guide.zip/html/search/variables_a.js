var searchData=
[
  ['wordlength',['wordlength',['../structp__adcuUartOpt.html#afce52c05d3e6b825b5eb6f36b3c44017',1,'p_adcuUartOpt']]]
];
