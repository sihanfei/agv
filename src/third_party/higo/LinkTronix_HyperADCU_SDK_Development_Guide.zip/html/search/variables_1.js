var searchData=
[
  ['can_5fdata',['can_data',['../structp__adcuCanData.html#a704eab46dad820c0565d3f81d2340f66',1,'p_adcuCanData']]],
  ['ccs',['ccs',['../structp__adcuLinData.html#a7f744409bf1999626d8d95f1c0439864',1,'p_adcuLinData']]]
];
