var searchData=
[
  ['adcu_5fdev_5fstatus',['ADCU_DEV_STATUS',['../adcuSDK_8h.html#ac17b18a9af8348235809ab6b9254daee',1,'adcuSDK.h']]],
  ['adcudevicechannel',['adcuDeviceChannel',['../device_8h.html#a7350345e7afc7ed49977f8b4d5bd1b47',1,'device.h']]],
  ['adcudevicetype',['adcuDeviceType',['../device_8h.html#afb17ec392c76861e7a30a117a434a07f',1,'device.h']]]
];
