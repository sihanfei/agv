var searchData=
[
  ['state',['state',['../structp__adcuHSData.html#a0b57aa10271a66f3dc936bba1d2f3830',1,'p_adcuHSData']]],
  ['stopbit',['stopbit',['../structp__adcuUartOpt.html#a91e0d9bab8efe775f6062cc81fe7bdfe',1,'p_adcuUartOpt']]]
];
