var searchData=
[
  ['can_5fdata_5fsize',['CAN_DATA_SIZE',['../device_8h.html#acf897332482a87a49a6f253f42b3456d',1,'device.h']]]
];
