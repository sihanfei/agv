var searchData=
[
  ['can_5fdata',['can_data',['../structp__adcuCanData.html#a704eab46dad820c0565d3f81d2340f66',1,'p_adcuCanData']]],
  ['can_5fdata_5fsize',['CAN_DATA_SIZE',['../device_8h.html#acf897332482a87a49a6f253f42b3456d',1,'device.h']]],
  ['ccs',['ccs',['../structp__adcuLinData.html#a7f744409bf1999626d8d95f1c0439864',1,'p_adcuLinData']]]
];
